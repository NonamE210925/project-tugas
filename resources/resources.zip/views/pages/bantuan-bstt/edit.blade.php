@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('bantuanBstt.update', $data->id) }}" method="POST" class="forms-sample" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="bencana_id">Bencana</label>->
                            <select class="js-example-basic-single w-100 form-control @error('bencana_id') is-invalid @enderror" name="bencana_id">
                                <option>-- Pilih Bencana --</option>
                                @foreach($bencana as $ben)
                                <option value="{{ $ben->id}}" {{ $ben->id == $data->bencana_id ? 'selected' : '' }}>{{ $ben->judul}}</option>
                                @endforeach
                            </select>
                            @error('bencana_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="korban_id">Nama Korban </label>->
                            <select class="js-example-basic-single w-100 form-control @error('korban_id') is-invalid @enderror" name="korban_id">
                                <option>-- Pilih Korban --</option>
                                @foreach($korban as $ko)
                                <option value="{{ $ko->id}}" {{ $ko->id == $data->korban_id ? 'selected' : '' }}>{{ $ko->nik}}-{{ $ko->nama}}</option>
                                @endforeach
                            </select>
                            @error('korban_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" class="form-control @error('nik') is-invalid @enderror" id="nik"
                                name="nik" placeholder="NIK" value="{{ old('nik') ?? $data->nik }}">
                            @error('nik')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="kk">KK</label>
                            <input type="text" class="form-control @error('kk') is-invalid @enderror" id="kk"
                                name="kk" placeholder="KK" value="{{ old('kk') ?? $data->kk}}">
                            @error('kk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="jumlah">Jumlah Jiwa</label>
                            <input type="text" class="form-control @error('jumlah') is-invalid @enderror" id="jumlah"
                                name="jumlah" placeholder="Jumlah Jiwa" value="{{ old('jumlah') ?? $data->jumlah}}">
                            @error('jumlah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <textarea name="keterangan" class="form-control @error('keterangan') is-invalid @enderror" >{!! old('keterangan', $data->keterangan)  !!}</textarea>
                            @error('keterangan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Dampak Kejadian</label>
                            <textarea name="dampak" class="form-control @error('dampak') is-invalid @enderror" >{!! old('dampak', $data->keterangan)  !!}</textarea>
                            @error('keterangan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="jumlah">Foto Kerusakan</label>
                            <input type="file" class="form-control @error('foto') is-invalid @enderror" id="foto"
                                name="foto" placeholder="Jumlah Jiwa">
                            <!-- <a href="{{ asset('uploads/foto-kerusakan/' . $data->foto) }}" target="_blank">Lihat foto lama</a> -->
                            <div>
                                <img id="imgPreview" src="#" alt="pic" class="img-fluid" />
                            </div>
                            @error('foto')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="sp_kelurahan">Surat Pengajuan Dari Kelurahan</label>
                            <input type="text" class="form-control @error('sp_kelurahan') is-invalid @enderror" id="sp_kelurahan"
                                name="sp_kelurahan" placeholder="Surat Pengajuan Kelurahan" value="{{ old('sp_kelurahan') ?? $data->sp_kelurahan }}">
                            @error('sp_kelurahan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="sp_bpbd">Surat Pengajuan Dari BPBD</label>
                            <input type="text" class="form-control @error('sp_bpbd') is-invalid @enderror" id="sp_bpbd"
                                name="sp_bpbd" placeholder="Surat Pengajuan Kelurahan" value="{{ old('sp_bpbd') ?? $data->sp_bpbd }}">
                            @error('sp_bpbd')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="sp_pencairan">Surat Pencairan</label>
                            <input type="text" class="form-control @error('sp_pencairan') is-invalid @enderror" id="sp_pencairan"
                                name="sp_pencairan" placeholder="Surat Pencairan" value="{{ old('sp_pencairan') ?? $data->sp_pencairan }}">
                            @error('sp_pencairan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="tgl_pencairan">Tanggal Pencairan</label>
                            <input type="date" class="form-control @error('tgl_pencairan') is-invalid @enderror" id="tgl_pencairan"
                                name="tgl_pencairan" placeholder="Surat Pencairan" value="{{ old('tgl_pencairan') ?? $data->tgl_pencairan }}">
                            @error('tgl_pencairan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        
                     
                        
                        <button type="submit" class="btn btn-primary me-2">Tambah</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css') }}">
@endpush
@push('after-scripts')
    <script src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
    <script>
        $(document).ready(() => {
            $(".js-example-basic-single").select2();

            // preview image
            $('#foto').change(function() {
                const file = this.files[0];
                console.log(file);
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        console.log(event.target.result);
                        $('#imgPreview').attr('src', event.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
@endpush


