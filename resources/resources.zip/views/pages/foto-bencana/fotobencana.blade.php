@extends('layouts.app')

@section('content')
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <h3 class="m-3">{{ $pageName }}</h3>
        </div>
    </div>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-header">
                <a href="{{ route('fotobencana.tambah', $bencana->slug) }}" class="btn btn-warning btn-rounded btn-fw">Tambah Data</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="table_id">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $no = 1;
                            @endphp
                            @foreach ($fotoBencana as $fb)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td width="25%">
                                        <a href="{{ asset('uploads/foto-bencana/'. $fb->foto) }}" target="_blank">
                                        <img src="{{ asset('uploads/foto-bencana/'.$fb->foto) }}" class="w-50 h-75" style="border-radius: 0; ">
                                        </a>
                                    </td>
                                    <td>
                                        <a href="{{ route('fotobencana.edit', [$fb->id, $bencana->slug]) }}"><span
                                                class="badge badge-primary my-2">Edit</span></a>
                                        <form action="{{ route('fotobencana.destroy', [$fb->id, $bencana->slug]) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                onclick="return confirm('Anda yakin ingin menghapus foto ini?')"
                                                class="badge badge-danger">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                responsive: true
            });
        });
    </script>
@endpush
