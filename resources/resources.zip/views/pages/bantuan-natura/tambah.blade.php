@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('bantuanNatura.store') }}" method="POST" class="forms-sample">
                        @csrf
                        <div class="form-group">
                            <label for="exampleInputUsername1">Kejadian Bencana</label>
                            <select class="js-example-basic-single w-100" class="form-control" name="bencana_id">
                                <option> -pilih- </option>
                                @foreach ($bencana as $ben)
                                    @if ($ben->id == old('bencana_id'))
                                        <option value="{{ $ben->id }}" selected>{{ $ben->judul }} |
                                            <b>{{ $ben->jenis->jenis }}</b>
                                        </option>
                                    @else
                                        <option value="{{ $ben->id }}">{{ $ben->judul }} |
                                            <b>{{ $ben->jenis->jenis }}</b>
                                        </option>
                                    @endif
                                @endforeach
                            </select>
                            @error('bencana_id')
                                <div class="text-danger">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Korban Bencana</label>
                            <select class="js-example-basic-single w-100" class="form-control" name="korban_id">
                                <option> -pilih- </option>
                                @foreach ($korban as $kor)
                                    @if ($kor->id == old('korban_id'))
                                        <option value="{{ $kor->id }}" selected>{{ $kor->nik }} |
                                            <b>{{ $kor->nama }}</b>
                                        </option>
                                    @else
                                        <option value="{{ $kor->id }}">{{ $kor->nik }} |
                                            <b>{{ $kor->nama }}</b>
                                        </option>
                                    @endif
                                @endforeach
                            </select>
                            @error('korban_id')
                                <div class="text-danger">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">NIK Calon Penerima Bantuan</label>
                            <input type="text" name="nik" class="form-control @error('nik') is-invalid @enderror"
                                value="{{ old('nik') }}">
                            @error('nik')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">No KK</label>
                            <input type="text" name="kk" class="form-control @error('kk') is-invalid @enderror"
                                value="{{ old('kk') }}">
                            @error('kk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Jumlah Jiwa</label>
                            <input type="number" name="jumlah" class="form-control @error('jumlah') is-invalid @enderror"
                                value="{{ old('jumlah') }}">
                            @error('jumlah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Keterangan Anggota Keluarga</label>
                            <textarea name="keterangan" id="" cols="30" rows="10"
                                class="form-control @error('keterangan') is-invalid @enderror">{{ old('keterangan') }}</textarea>
                            @error('keterangan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">No Surat Usulan Kelurahan</label>
                            <input type="text" name="surat_usulan"
                                class="form-control @error('surat_usulan') is-invalid @enderror"
                                value="{{ old('surat_usulan') }}">
                            @error('surat_usulan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">No BA Penyerahan DINSOS </label>
                            <input type="text" name="berita_acara"
                                class="form-control @error('berita_acara') is-invalid @enderror"
                                value="{{ old('berita_acara') }}">
                            @error('berita_acara')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value=""> -Pilih- </option>
                                <option value="sudah" {{ old('status') == 'sudah' ? 'selected' : '' }}>Sudah</option>
                                <option value="belum" {{ old('status') == 'belum' ? 'selected' : '' }}>Belum</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Tambah</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css') }}">
@endpush
@push('after-scripts')
    <script src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
    <script>
        $(document).ready(() => {
            $(".js-example-basic-single").select2();
        })
    </script>
@endpush
