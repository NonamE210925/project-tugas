@extends('layouts.app')

@section('content')
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <h3 class="m-3">{{ $pageName }}</h3>
        </div>
    </div>

    @if (session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
    @endif
    @if (session()->has('error'))
        <div class="alert alert-danger">
            {{ session()->get('error') }}
        </div>
    @endif
    
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-header">
                <a href="{{ route('korban.tambah', $bencana->slug) }}" class="btn btn-warning btn-rounded btn-fw">Tambah Korban</a>
                <a href="{{ route('bencana') }}" class="btn btn-primary btn-rounded btn-fw">Kembali</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="table_id">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Judul Bencana</th>
                                <th>NIK</th>
                                <th>KK</th>
                                <th>Nama Lengkap</th>
                                <th>Nama Panggilan</th>
                                <th>Jenis Kelamin</th>
                                <th>Usia</th>
                                <th>Kategori Usia</th>
                                <th>Kondisi Korban</th>
                                <th>Disabilitas</th>
                                <th>Keterangan</th>
                                <th>Kelurahan</th>
                                <th>RW</th>
                                <th>RT</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($korban as $no => $dt)
                            <tr>
                                <td>{{ $no+1 }}</td>
                                <td>{{ $dt->bencana->judul }}</td>
                                <td>{{ $dt->nik }}</td>
                                <td>{{ $dt->kk }}</td>
                                <td>{{ $dt->nama }}</td>
                                <td>{{ $dt->panggilan }}</td>
                                <td>
                                    @if($dt->jk == 'L')
                                        Laki-laki
                                    @else
                                        Perempuan
                                    @endif
                                </td>
                                <td>{{ $dt->usia }} Tahun</td>
                                <td>{{ $dt->kategoriusia->kategori_usia }}</td>
                                <td>{{ $dt->kondisikorban->kondisikorban }}</td>
                                <td>
                                    @if($dt->disabilitas == 'T')
                                        Tidak
                                    @else
                                        Ya
                                    @endif
                                </td>
                                <td>{{ $dt->keterangan }}</td>
                                <td>{{ $dt->kelurahan->nama_kelurahan }}</td>
                                <td>{{ $dt->rw }}</td>
                                <td>{{ $dt->rt }}</td>
                                <td>{{ $dt->alamat }}</td>
                                <td>
                                    <a href="{{ route('korban.edit', [$dt->id, $bencana->slug]) }}"><span
                                            class="badge badge-primary my-2">Edit</span></a>
                                    <form action="{{ route('korban.destroy',[$dt->id, $bencana->slug]) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            onclick="return confirm('Anda yakin ingin menghapus data ?')" class="badge
                                            badge-danger">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                responsive: true
            });
        });
    </script>
@endpush
