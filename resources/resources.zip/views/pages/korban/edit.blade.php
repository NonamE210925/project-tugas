@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('korban.update', [$data->id, $bencana->slug]) }}" method="POST" class="forms-sample">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="bencana_id">Judul Bencana</label>->
                            <input type="hidden" name="bencana_id" value="{{ $bencana->id }}">
                            <input type="text" class="form-control @error('bencana_id') is-invalid @enderror" value="{{ $bencana->judul }}" disabled>
                            @error('bencana_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" class="form-control @error('nik') is-invalid @enderror" id="nik"
                                name="nik" placeholder="NIK" value="{{ old('nik') ?? $data->nik }}">
                            @error('nik')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="kk">KK</label>
                            <input type="text" class="form-control @error('kk') is-invalid @enderror" id="kk"
                                name="kk" placeholder="KK" value="{{ old('kk') ?? $data->kk}}">
                            @error('kk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="nama">Nama Lengkap</label>
                            <input type="text" class="form-control @error('nama') is-invalid @enderror" id="nama"
                                name="nama" placeholder="Nama Lengkap" value="{{ old('nama') ?? $data->nama}}">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="panggilan">Nama Panggilan</label>
                            <input type="text" class="form-control @error('panggilan') is-invalid @enderror" id="panggilan"
                                name="panggilan" placeholder="Nama Panggilan" value="{{ old('panggilan') ?? $data->panggilan }}">
                            @error('panggilan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="jk">Jenis Kelamin</label>
                            <!-- <input type="text" class="form-control @error('jk') is-invalid @enderror" id="jk"
                                name="panggilan" placeholder="Nama Panggilan" value="{{ old('jk') }}"> -->
                            <select class="js-example-basic-single w-100" name="jk">
                                <option value="">-- Jenis Kelamin --</option>
                                <option value="L"  {{ $data->jk == "L" ? 'selected' : ''}}>Laki-laki</option>
                                <option value="P"  {{ $data->jk == "P" ? 'selected' : ''}}>Perempuan</option>
                                <option value="T"  {{ $data->jk == "T" ? 'selected' : ''}}>Tidak Diketahui</option>
                            </select>
                            @error('jk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="usia">Usia</label>
                            <input type="number" class="form-control @error('usia') is-invalid @enderror" id="usia"
                                name="usia" placeholder="Usia" value="{{ old('usia') ?? $data->usia }}">
                            @error('usia')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="kategoriusia_id">Kategori Usia</label>->
                            <select class="js-example-basic-single w-100" name="kategoriusia_id">
                                <option>-- Pilih Kategori Usia --</option>
                                @foreach($katusia as $ku)
                                <option value="{{ $ku->id}}" {{ $ku->id == $data->kategoriusia_id ? 'selected' : '' }}>{{ $ku->kategori_usia}}</option>
                                @endforeach
                            </select>
                            @error('kategoriusia_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="kondisi_id">Kondisi Korban</label>->
                            <select class="js-example-basic-single w-100" name="kondisi_id">
                                <option>-- Pilih Kondisi Korban --</option>
                                @foreach($kondisi as $ko)
                                <option value="{{ $ko->id}}" {{ $ko->id == $data->kondisi_id ? 'selected' : '' }}>{{ $ko->kondisikorban}}</option>
                                @endforeach
                            </select>
                            @error('kondisi_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="disabilitas">Disabilitas</label>->
                            <select class="js-example-basic-single w-100" name="disabilitas">
                                <option value="">-- Disabilitas --</option>
                                <option value="Y" {{ $data->disabilitas == "Y" ? 'selected' : ''}} >Ya</option>
                                <option value="T" {{ $data->disabilitas == "T" ? 'selected' : ''}} >Tidak</option>
                            </select>
                            @error('disabilitas')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <!-- <textarea></textarea> -->
                            <textarea name="keterangan" class="form-control @error('keterangan') is-invalid @enderror" >{!! old('keterangan',  $data->keterangan)  !!}</textarea>
                            @error('keterangan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="kelurahan_id">Kelurahan</label>->
                            <select class="js-example-basic-single w-100" name="kelurahan_id">
                                <option>-- Pilih Kelurahan --</option>
                                @foreach($kelurahan as $kel)
                                <option value="{{ $kel->id}}" {{ $kel->id == $data->kelurahan_id ? 'selected' : '' }}>{{$kel->nama_kelurahan}}</option>
                                @endforeach
                            </select>
                            @error('kelurahan_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="rw">RW</label>
                            <input type="text" class="form-control @error('rw') is-invalid @enderror" id="nik"
                                name="rw" placeholder="RW" value="{{ old('rw') ?? $data->rw }}">
                            @error('rw')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="rt">RT</label>
                            <input type="text" class="form-control @error('rt') is-invalid @enderror" id="rt"
                                name="rt" placeholder="RT" value="{{ old('rt') ?? $data->rt}}">
                            @error('rt')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <!-- <textarea></textarea> -->
                            <textarea name="alamat" class="form-control @error('alamat') is-invalid @enderror" >{!! old('alamat',  $data->alamat)  !!}</textarea>
                            @error('alamat')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                     
                        
                        <button type="submit" class="btn btn-primary me-2">Tambah</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('before-styles')
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css') }}">
@endpush

@push('after-scripts')
    <script src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
    <script>
        $(document).ready(() => {
            $(".js-example-basic-single").select2();

            // preview image
            $('#foto').change(function() {
                const file = this.files[0];
                console.log(file);
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        console.log(event.target.result);
                        $('#imgPreview').attr('src', event.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
@endpush
