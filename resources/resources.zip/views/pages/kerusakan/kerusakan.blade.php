@extends('layouts.app')

@section('content')
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <h3 class="m-3">{{ $pageName }}</h3>
        </div>
    </div>
    @if (session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
    @endif
    @if (session()->has('error'))
        <div class="alert alert-danger">
            {{ session()->get('error') }}
        </div>
    @endif
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-header">
                <a href="{{ route('kerusakan.tambah', $bencana->slug) }}" class="btn btn-warning btn-rounded btn-fw">Tambah Data</a>
                <a href="{{ route('bencana') }}" class="btn btn-primary btn-rounded btn-fw">Kembali</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="table_id">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Jenis Kerusakan</th>
                                <th>Jenis Bangunan</th>
                                <th>Sektor</th>
                                <th>Tingkat Kerusakan</th>
                                <th>Taksiran Kerugian</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $no = 1;
                            @endphp
                            @foreach ($kerusakan as $k)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ $k->jeniskerusakan }}</td>
                                    <td>
                                        @if(!empty($k->bangunan->bangunan))
                                        {{ $k->bangunan->bangunan }}
                                        @else
                                        -
                                        @endif
                                    </td>
                                    <td>@if(!empty($k->sektor->sektor))
                                        {{ $k->sektor->sektor }}
                                        @else
                                        -
                                        @endif
                                    </td>
                                    <td>{{ $k->kerusakan }}</td>
                                    <td>Rp {{ number_format($k->kerugian, 0) }}</td>
                                    <td>
                                        <a href="{{ route('kerusakan.edit', [$k->id, $bencana->slug]) }}"><span
                                                class="badge badge-primary my-2">Edit</span></a>
                                        <form action="{{ route('kerusakan.destroy', [$k->id, $bencana->slug]) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                onclick="return confirm('Anda yakin ingin menghapus data kerusakan ini?')"
                                                class="badge badge-danger">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                responsive: true
            });
        });
    </script>
@endpush
