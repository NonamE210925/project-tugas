@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('kerusakan.store', $bencana->slug) }}" method="POST" class="forms-sample">
                        @csrf
                        <div class="form-group">
                            <label for="exampleInputUsername1">Judul Bencana</label>
                            <input type="hidden" name="bencana_id" value="{{ $bencana->id }}">
                            <input type="text" class="form-control @error('bencana_id') is-invalid @enderror" value="{{ $bencana->judul }}" disabled>
                            @error('bencana_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Jenis Kerusakan</label>
                            <select name="jeniskerusakan" id="jeniskerusakan" class="form-control js-example-basic-single w-100">
                                <option value="">-- Pilih Jenis Kerusakan --</option>
                                <option value="Bangunan" {{ old('jeniskerusakan') == 'Bangunan' ? 'selected' : '' }}>Bangunan</option>
                                <option value="Sektor" {{ old('jeniskerusakan') == 'Sektor' ? 'selected' : '' }}>Sektor</option>
                            </select>
                            @error('jeniskerusakan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group" style="display:none" id="bangunan">
                            <label for="exampleInputUsername1">Bangunan</label><br>
                            <select class="form-control js-example-basic-single w-100" name="bangunan_id" id="bangunan_id" oninvalid="this.setCustomValidity('Harap pilih data bangunan')" oninput="setCustomValidity('')">
                                <option value="">-- Pilih Bangunan --</option>
                                @foreach ($bangunan as $bg)
                                    <option value="{{ $bg->id }}" {{ old('bangunan_id') == $bg->id ? 'selected' : '' }}>{{ $bg->bangunan }}</option>
                                @endforeach
                            </select>
                            @error('bangunan_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group" style="display:none" id="sektor">
                            <label for="exampleInputUsername1">Sektor</label><br>
                            <select class="form-control js-example-basic-single w-100" name="sektor_id" id="sektor_id" oninvalid="this.setCustomValidity('Harap pilih data sektor')" oninput="setCustomValidity('')">
                                <option value="">-- Pilih Sektor --</option>
                                @foreach ($sektor as $s)
                                    <option value="{{ $s->id }}" {{ old('sektor_id') == $s->id ? 'selected' : '' }}>{{ $s->sektor }} - {{ $s->bidang }}</option>
                                @endforeach
                            </select>
                            @error('sektor_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Kerusakan</label>
                            <select name="kerusakan" class="form-control js-example-basic-single w-100">
                                <option value="">-- Pilih Tingkat Kerusakan --</option>
                                <option value="RB" {{ old('tingkatkerusakan') == 'RB' ? 'selected' : '' }}>Rusak Berat (RB)</option>
                                <option value="RS" {{ old('tingkatkerusakan') == 'RS' ? 'selected' : '' }}>Rusak Sedang (RS)</option>
                                <option value="RR" {{ old('tingkatkerusakan') == 'RR' ? 'selected' : '' }}>Rusak Ringan (RR)</option>
                            </select>
                            @error('kerusakan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Taksiran Kerugian (Dalam Rupiah)</label>
                            <input type="number" class="form-control @error('kerugian') is-invalid @enderror" id="kerugian"
                                name="kerugian" placeholder="Taksiran Kerugian (Dalam Rupiah)" value="{{ old('kerugian') }}">
                            @error('kerugian')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Tambah</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css') }}">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
    <script type="text/javascript" charset="utf8" src="{{ asset('assets/js/select2.js') }}"></script>
    <script>
    $(document).ready(function() {
    $('#jeniskerusakan').on('change', function() {
        var kerusakan = $(this).val();
        var ib = document.getElementById("bangunan");
        var b = document.getElementById("bangunan_id");
        var is = document.getElementById("sektor");
        var s = document.getElementById("sektor_id");
        
        if(kerusakan == 'Bangunan') {
        ib.style.display = "block";
        b.required = true;
        b.disable = false;
        s.required = false;
        s.disable = true;
        is.style.display = "none"; 
        }
        else if (kerusakan == 'Sektor') {
        ib.style.display = "none";
        is.style.display = "block";
        s.required = true;
        s.disable = false;
        b.required = false;
        b.disable = true;
        }
    });
    });
    </script>
@endpush
