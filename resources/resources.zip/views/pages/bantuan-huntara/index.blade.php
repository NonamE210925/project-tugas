@extends('layouts.app')

@section('content')
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <h3 class="m-3">{{ $pageName }}</h3>
        </div>
    </div>
    @if (session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
    @endif
    @if (session()->has('error'))
        <div class="alert alert-danger">
            {{ session()->get('error') }}
        </div>
    @endif
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-header">
                <a href="{{ route('bantuanHuntara.tambah') }}" class="btn btn-warning btn-rounded btn-fw">Tambah Data</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="table_id">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Bencana</th>
                                <th>Nama Korban</th>
                                <th>NIK</th>
                                <th>KK</th>
                                <th>Jumlah Jiwa</th>
                                <th>Keterangan</th>
                                <th>Volume</th>
                                <th>Bank</th>
                                <th>No. Rekening</th>
                                <th>Nama Pemilik</th>
                                <th>Tanggal Usulan</th>
                                <th>Tanggal Pencairan</th>
                                <th>Jumlah</th>
                                <th>PPH</th>
                                <th>Jumlah Pembayaran</th>
                                <th>Status Pencairan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $no = 1;
                            @endphp
                            @foreach ($huntara as $h)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ $h->bencana->judul }}</td>
                                    <td>{{ $h->korban->nama }}</td>
                                    <td>{{ $h->nik }}</td>
                                    <td>{{ $h->kk }}</td>
                                    <td>{{ $h->jumlah_jiwa }}</td>
                                    <td>{{ $h->keterangan }}</td>
                                    <td>{{ $h->volume }}</td>
                                    <td>{{ $h->bank->bank }}</td>
                                    <td>{{ $h->rekening }}</td>
                                    <td>{{ $h->nama_pemilik }}</td>
                                    <td>{{ date('d-m-Y', strtotime($h->tgl_usulan)) }}</td>
                                    <td>{{ date('d-m-Y', strtotime($h->tgl_pencairan)) }}</td>
                                    <td>Rp {{ number_format($h->jumlah, 2) }}</td>
                                    <td>Rp {{ number_format($h->pph, 2) }}</td>
                                    <td>Rp {{ number_format($h->jml_bayar, 2) }}</td>
                                    <td>
                                        @if($h->status == "Sudah")<button class="badge badge-success">
                                        @elseif($h->status == "Pending")<button class="badge badge-warning">
                                        @else<button class="badge badge-danger">
                                        @endif
                                        {{ $h->status }}
                                        </button>
                                    </td>
                                    <td>
                                        <a href="{{ route('bantuanHuntara.edit', $h->id) }}"><span
                                                class="badge badge-primary my-2">Edit</span></a>
                                        <form action="{{ route('bantuanHuntara.destroy', $h->id) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                onclick="return confirm('Anda yakin ingin menghapus data bantuan huntara ini?')"
                                                class="badge badge-danger">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                responsive: true
            });
        });
    </script>
@endpush
