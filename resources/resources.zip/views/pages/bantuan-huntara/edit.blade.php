@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('bantuanHuntara.update', $huntara->id) }}" method="POST" class="forms-sample">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="exampleInputUsername1">Bencana</label>
                            <select class="form-control js-example-basic-single w-100" name="bencana_id">
                                <option value="">-- Pilih Bencana --</option>
                                @foreach ($bencana as $b)
                                    @if ($b->id == old('bencana_id') || $b->id ==  $huntara->bencana_id)
                                        <option value="{{ $b->id }}" selected>{{ $b->judul }}</option>
                                    @else
                                        <option value="{{ $b->id }}">{{ $b->judul }}</option>
                                    @endif
                                @endforeach
                            </select>
                            @error('bencana_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Korban</label>
                            <select class="form-control js-example-basic-single w-100" name="korban_id">
                                <option value="">-- Pilih Korban --</option>
                                @foreach ($korban as $k)
                                    @if ($k->id == old('korban_id') || $k->id == $huntara->korban_id)
                                        <option value="{{ $k->id }}" selected>{{ $k->nama }}</option>
                                    @else
                                        <option value="{{ $k->id }}">{{ $k->nama }}</option>
                                    @endif
                                @endforeach
                            </select>
                            @error('korban_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">NIK</label>
                            <input type="text" class="form-control @error('nik') is-invalid @enderror"
                                name="nik" placeholder="NIK" value="{{ old('nik') ?? $huntara->nik}}">
                            @error('nik')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">KK</label>
                            <input type="text" class="form-control @error('kk') is-invalid @enderror"
                                name="kk" placeholder="KK" value="{{ old('kk') ?? $huntara->kk}}">
                            @error('kk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Jumlah Jiwa</label>
                            <input type="number" class="form-control @error('jumlah_jiwa') is-invalid @enderror"
                                name="jumlah_jiwa" placeholder="Jumlah Jiwa" value="{{ old('jumlah_jiwa') ?? $huntara->jumlah_jiwa}}">
                            @error('jumlah_jiwa')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Keterangan</label>
                            <textarea class="form-control" name="keterangan">
                                {{ old('keterangan') ?? $huntara->keterangan}}
                            </textarea>
                            @error('keterangan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Volume</label>
                            <input type="number" class="form-control @error('volume') is-invalid @enderror"
                                name="volume" placeholder="Volume" value="{{ old('volume') ?? $huntara->volume}}">
                            @error('volume')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Bank</label>
                            <select class="form-control js-example-basic-single w-100" name="bank_id">
                                <option value="">-- Pilih Bank --</option>
                                @foreach ($bank as $b)
                                    @if ($b->id == old('bank_id') || $b->id == $huntara->bank_id)
                                        <option value="{{ $b->id }}" selected>{{ $b->bank }}</option>
                                    @else
                                        <option value="{{ $b->id }}">{{ $b->bank }}</option>
                                    @endif
                                @endforeach
                            </select>
                            @error('bank_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Rekening</label>
                            <input type="text" class="form-control @error('rekening') is-invalid @enderror"
                                name="rekening" placeholder="Nomor Rekening" value="{{ old('rekening') ?? $huntara->rekening}}">
                            @error('rekening')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Nama Pemilik</label>
                            <input type="text" class="form-control @error('nama_pemilik') is-invalid @enderror"
                                name="nama_pemilik" placeholder="Nama Pemilik" value="{{ old('nama_pemilik') ?? $huntara->nama_pemilik}}">
                            @error('nama_pemilik')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Tanggal Usulan</label>
                            <input type="date" class="form-control @error('tgl_usulan') is-invalid @enderror"
                                name="tgl_usulan" placeholder="Tanggal Usulan" value="{{ old('tgl_usulan') ?? $huntara->tgl_usulan}}">
                            @error('tgl_usulan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Tanggal Pencairan</label>
                            <input type="date" class="form-control @error('tgl_pencairan') is-invalid @enderror"
                                name="tgl_pencairan" placeholder="Tanggal Pencairan" value="{{ old('tgl_pencairan') ?? $huntara->tgl_pencairan}}">
                            @error('tgl_pencairan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Jumlah</label>
                            <input type="number" class="form-control @error('jumlah') is-invalid @enderror"
                                name="jumlah" placeholder="Jumlah" value="{{ old('jumlah') ?? $huntara->jumlah}}">
                            @error('jumlah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">PPH</label>
                            <input type="number" class="form-control @error('pph') is-invalid @enderror"
                                name="pph" placeholder="PPH" value="{{ old('pph') ?? $huntara->pph}}">
                            @error('pph')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Jumlah yang Dibayarkan</label>
                            <input type="number" class="form-control @error('jml_bayar') is-invalid @enderror"
                                name="jml_bayar" placeholder="Jumlah yang Dibayarkan" value="{{ old('jml_bayar') ?? $huntara->jml_bayar}}">
                            @error('jml_bayar')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="exampleInputUsername1">Status Pencairan</label>
                            <select name="status" class="form-control js-example-basic-single w-100">
                                <option value="">-- Pilih Status Pencairan--</option>
                                <option value="Sudah" {{ old('status') == 'Sudah' || $huntara->status == 'Sudah' ? 'selected' : '' }}>Sudah</option>
                                <option value="Pending" {{ old('status') == 'Pending' || $huntara->status == 'Pending' ? 'selected' : '' }}>Pending</option>
                                <option value="Belum" {{ old('status') == 'Belum' || $huntara->status == 'Belum' ? 'selected' : '' }}>Belum</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Update</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css') }}">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
    <script type="text/javascript" charset="utf8" src="{{ asset('assets/js/select2.js') }}"></script>
@endpush
