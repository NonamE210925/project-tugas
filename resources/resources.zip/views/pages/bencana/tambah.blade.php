@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('bencana.store') }}" method="POST" class="forms-sample"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Judul Bencana (Hari, Bencana dan Kelurahan)</label>
                                    <input type="text" class="form-control @error('judul') is-invalid @enderror"
                                        id="judul" name="judul" placeholder="Hari, Bencana dan Kelurahan" value="{{ old('judul') }}">
                                    @error('judul')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="">Jenis Bencana</label>
                                    <select
                                        class="js-example-basic-single form-control @error('jenis_id') is-invalid @enderror"
                                        name="jenis_id">
                                        <option> -pilih- </option>
                                        @foreach ($jenisBencana as $jb)
                                            @if ($jb->id == old('jenis_id'))
                                                <option value="{{ $jb->id }}" selected>{{ $jb->jenis }}</option>
                                            @else
                                                <option value="{{ $jb->id }}">{{ $jb->jenis }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                    @error('jenis_id')
                                        <div class="text-danger">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Tanggal</label>
                                            <input type="date" name="tgl"
                                                class="form-control @error('tgl') is-invalid @enderror"
                                                value="{{ old('tgl') }}">
                                            @error('tgl')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Waktu</label>
                                            <input type="time" name="waktu" id="waktu"
                                                class="form-control @error('waktu') is-invalid @enderror"
                                                value="{{ old('waktu') }}">
                                            @error('waktu')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="">Kelurahan</label>
                                    <select class="js-example-basic-single form-control" name="kelurahan_id">
                                        <option> -pilih- </option>
                                        @foreach ($kelurahan as $kel)
                                            @if ($kel->id == old('kelurahan_id'))
                                                <option value="{{ $kel->id }}" selected>{{ $kel->nama_kelurahan }}
                                                </option>
                                            @else
                                                <option value="{{ $kel->id }}">{{ $kel->nama_kelurahan }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                    @error('kelurahan_id')
                                        <div class="text-danger">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="">Alamat</label>
                                    <textarea class="form-control @error('alamat') is-invalid @enderror" id="exampleTextarea1" rows="4"
                                        name="alamat">{{ old('alamat') }}</textarea>
                                    @error('alamat')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="">Cakupan</label>
                                    <input type="text" name="cakupan"
                                        class="form-control @error('cakupan') is-invalid @enderror"
                                        value="{{ old('cakupan') }}">
                                    @error('cakupan')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Latitude</label>
                                            <input type="text" name="lat" id="lat"
                                                class="form-control @error('lat') is-invalid @enderror"
                                                value="{{ old('lat') }}">
                                            @error('lat')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Longtitude</label>
                                            <input type="text" name="lng" id="lng"
                                                class="form-control @error('lng') is-invalid @enderror"
                                                value="{{ old('lng') }}">
                                            @error('lng')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="">Penyebab</label>
                                    <textarea name="penyebab" id="penyebab" rows="3" class="form-control @error('penyebab') is-invalid @enderror">{{ old('penyebab') }}</textarea>
                                    @error('penyebab')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="">Deskripsi</label>
                                    <textarea name="deskripsi" id="deskripsi" rows="3" class="form-control @error('deskripsi') is-invalid @enderror">{{ old('deskripsi') }}</textarea>
                                    @error('deskripsi')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Foto Bencana</label>
                                    <div>
                                        <img id="imgPreview" src="#" alt="pic" class="img-fluid" />
                                    </div>
                                    <input type="file" name="foto" id="foto"
                                        class="form-control @error('foto') is-invalid @enderror">
                                    @error('foto')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Peta Geojson</label>
                                    <input type="file" name="peta" id="peta"
                                        class="form-control @error('peta') is-invalid @enderror">
                                    @error('peta')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Tambah</button>
                        <button type="reset" class="btn btn-light">Reset</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css') }}">
@endpush
@push('after-scripts')
    <script src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
    <script>
        $(document).ready(() => {
            $(".js-example-basic-single").select2();

            // preview image
            $('#foto').change(function() {
                const file = this.files[0];
                console.log(file);
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        console.log(event.target.result);
                        $('#imgPreview').attr('src', event.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
@endpush
