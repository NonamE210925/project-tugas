@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <h3 class="m-3">{{ $pageName }}</h3>
            </div>
        </div>
        @if (session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif
        @if (session()->has('error'))
            <div class="alert alert-danger">
                {{ session()->get('error') }}
            </div>
        @endif
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-header">
                    <a href="{{ route('bencana.tambah') }}" class="btn btn-warning btn-rounded btn-fw">Tambah Data</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="table_id">
                            <thead>
                                <tr>
                                    <th>
                                        No
                                    </th>
                                    <th>
                                        Judul
                                    </th>
                                    <th>
                                        Jenis
                                    </th>
                                    <th>Tanggal dan Waktu</th>
                                    <th>Kelurahan</th>
                                    <th>Alamat</th>
                                    <th>Cakupan</th>
                                    <th>Foto</th>
                                    <th>Korban</th>
                                    <th>Kerusakan</th>
                                    <th>Foto-Foto</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $no = 1;
                                @endphp
                                @foreach ($Bencana as $ben)
                                    <tr>
                                        <td>{{ $no++ }}</td>
                                        <td>{{ $ben->judul }}</td>
                                        <td>{{ $ben->jenis->jenis }}</td>
                                        <td>
                                            {{ $ben->tgl->isoFormat('D MMMM Y') }}, {{ $ben->waktu }}
                                        </td>
                                        <td>{{ $ben->kelurahan->nama_kelurahan }}</td>
                                        <td>{{ $ben->alamat }}</td>
                                        <td>{{ $ben->cakupan }}</td>
                                        <td>
                                            <a href="{{ asset('uploads/kejadian-bencana/' . $ben->foto) }}"
                                                target="_blank">Lihat Foto</a>
                                        </td>
                                        <td>
                                            <a href="{{ route('korban.bencana', $ben->slug) }}"><span
                                                    class="badge badge-primary my-2">Lihat Korban</span></a>
                                        </td>
                                        <td>
                                            <a href="{{ route('kerusakan.bencana', $ben->slug) }}"><span
                                                    class="badge badge-primary my-2">Lihat Kerusakan</span></a>
                                        </td>
                                        <td>
                                            <a href="{{ route('fotobencana.bencana', $ben->slug) }}"><span
                                                    class="badge badge-success my-2">Lihat Foto-Foto Bencana</span></a>
                                        </td>
                                        <td>
                                            <a href="{{ route('bencana.edit', $ben->id) }}"><span
                                                    class="badge badge-primary my-2">Edit</span></a>
                                            <form action="{{ route('bencana.destroy', $ben->id) }}" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit"
                                                    onclick="return confirm('Anda yakin ingin menghapus data ?')"
                                                    class="badge
                                            badge-danger">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('before-styles')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
@endpush
@push('after-scripts')
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#table_id').DataTable({
                responsive: true
            });
        });
    </script>
@endpush
