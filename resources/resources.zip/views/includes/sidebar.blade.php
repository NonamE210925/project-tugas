<nav class="sidebar-dark sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item {{ request()->is('/') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('home') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item nav-category">Master</li>
        <li class="nav-item {{ request()->is('jenis-bencana*') ? 'active' : '' }}">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
                aria-controls="ui-basic">
                <i class="menu-icon mdi mdi-floor-plan"></i>
                <span class="menu-title">Master</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse {{ request()->is('jenis-bencana*') ? 'show' : '' }}" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('jenisbencana') }}">Jenis Bencana</a></li>
                </ul>
            </div>
            <div class="collapse {{ request()->is('foto-bencana*') ? 'show' : '' }}" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('fotobencana') }}">Foto Bencana</a></li>
                </ul>
            </div>
            <div class="collapse {{ request()->is('kecamatan*') ? 'show' : '' }}" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('kecamatan') }}">Kecamatan</a></li>
                </ul>
            </div>
            <div class="collapse {{ request()->is('kelurahan*') ? 'show' : '' }}" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('kelurahan') }}">Kelurahan</a></li>
                </ul>
            </div>

            <div class="collapse {{ request()->is('berita*') ? 'show' : '' }}" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('berita') }}">Berita Bencana</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item nav-category">Kebencanaan</li>
        <li class="nav-item {{ request()->is('kejadian-bencana*') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('bencana') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Kejadian Bencana</span>
            </a>

        </li>

        <li class="nav-item {{ request()->is('kerusakan*') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('kerusakan') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Kerusakan</span>
            </a>

        </li>

        <li class="nav-item {{ request()->is('korban*') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('korban') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Korban</span>
            </a>

        </li>

        <li class="nav-item nav-category">Bantuan</li>
        <li class="nav-item {{ request()->is('bantuan-natura*') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('bantuanNatura') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Bantuan Natura</span>
            </a>
        </li>

        <li class="nav-item {{ request()->is('bantua-bstt*') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('bantuanBstt') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Bantuan BSTT</span>
            </a>
        </li>

        <li class="nav-item {{ request()->is('bantuan-huntara*') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('bantuanHuntara') }}">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Bantuan Huntara</span>
            </a>
        </li>
    </ul>
</nav>
