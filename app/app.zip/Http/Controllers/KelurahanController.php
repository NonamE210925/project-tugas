<?php

namespace App\Http\Controllers;

use App\Models\Kecamatan;
use App\Models\Kelurahan;
use Illuminate\Http\Request;

class KelurahanController extends Controller
{
    public function index()
    {
        $pageName   = "Kelurahan";
        $kelurahan  = Kelurahan::all();

        return view('pages.kelurahan.index', compact('pageName', 'kelurahan'));
    }

    public function add()
    {
        $pageName   = "Form Tambah Kelurahan";
        $kecamatan  = Kecamatan::all();

        return view('pages.kelurahan.tambah', compact('pageName','kecamatan'));
    }

    public function store(Request $request)
    {
        // dd($request);
        $validated = $request->validate([
            'nama_kelurahan' => 'required',
            'kecamatan_id'   => 'required',
        ], [
            'nama_kelurahan.required'   => 'Harap mengisi data',
            'kecamatan_id.required'     => 'Harap mengisi data',
        ]);

        $data = $request->all();
        $store = Kelurahan::create($data);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('kelurahan');
    }

    public function edit($id)
    {
        $pageName   = "Form Edit Data";
        $data       = Kelurahan::findOrFail($id);
        $kecamatan  = Kecamatan::all();

        return view('pages.kelurahan.edit', compact('pageName', 'data','kecamatan'));
    }
    
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'nama_kelurahan' => 'required',
            'kecamatan_id'   => 'required',
        ], [
            'nama_kelurahan.required'   => 'Harap mengisi data',
            'kecamatan_id.required'     => 'Harap mengisi data',
        ]);

        $data = $request->all();

        $kelurahan = Kelurahan::findOrFail($id);
        $update = $kelurahan->update($data);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('kelurahan');
    }

    public function destroy($id)
    {
        $kelurahan = Kelurahan::findOrFail($id);
        $delete = $kelurahan->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('kelurahan');

    }
}
