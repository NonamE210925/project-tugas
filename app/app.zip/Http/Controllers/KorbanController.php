<?php

namespace App\Http\Controllers;

use App\Models\Bencana;
use App\Models\KategoriUsia;
use App\Models\Kelurahan;
use App\Models\KondisiKorban;
use App\Models\Korban;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use function Ramsey\Uuid\v1;

class KorbanController extends Controller
{
    public function index()
    {
        $pageName   = "Korban";
        $data     = Korban::all();

        return view('pages.korban.index', compact('pageName', 'data'));
    }

    public function add($slug)
    {
        $pageName   = "Form Tambah Korban";
        $data       = Korban::all();
        // $bencana    = Bencana::all();
        $bencana    = Bencana::where('slug', $slug)->first();
        $katusia    = KategoriUsia::all();
        $kondisi    = KondisiKorban::all();
        $kelurahan  = Kelurahan::all();

        return view('pages.korban.tambah', compact('pageName','data','bencana','katusia','kondisi','kelurahan'));
    }

    public function store(Request $request, $slug)
    {
        // dd($request);
        $validated = $request->validate([
            'bencana_id'        => 'required',
            'nik'               => 'required',
            'kk'                => 'required',
            'nama'              => 'required',
            'panggilan'         => 'required',
            'jk'                => 'required',
            'usia'              => 'required',
            'kategoriusia_id'  => 'required',
            'kondisi_id'        => 'required',
            'disabilitas'       => 'required',
            'keterangan'        => 'required',
            'kelurahan_id'      => 'required',
            'rw'                => 'required',
            'rt'                => 'required',
            'alamat'            => 'required',
        ], [
            'bencana_id.required'       => 'Harap mengisi data',
            'nik.required'              => 'Harap mengisi data',
            'kk.required'               => 'Harap mengisi data',
            'nama.required'             => 'Harap mengisi data',
            'panggilan.required'        => 'Harap mengisi data',
            'jk.required'               => 'Harap mengisi data',
            'usia.required'             => 'Harap mengisi data',
            'kategoriusia_id.required' => 'Harap mengisi data',
            'kondisi_id.required'       => 'Harap mengisi data',
            'disabilitas.required'      => 'Harap mengisi data',
            'keterangan.required'       => 'Harap mengisi data',
            'kelurahan_id.required'     => 'Harap mengisi data',
            'rw.required'               => 'Harap mengisi data',
            'rt.required'               => 'Harap mengisi data',
            'alamat.required'           => 'Harap mengisi data',
        ]);

        
        // dd($data);
        $bencana = Bencana::where('slug', $slug)->first();

        $data = $request->all();
        $data['user_id'] = Auth::user()->id;
        Korban::create($data);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('korban.bencana', $bencana->slug);
    }

    public function edit($id,$slug)
    {
        $pageName   = "Form Edit Data";
        $data       = Korban::findOrFail($id);
        $bencana    = Bencana::where('slug', $slug)->first();
        // $bencana    = Bencana::all();
        $katusia    = KategoriUsia::all();
        $kondisi    = KondisiKorban::all();
        $kelurahan  = Kelurahan::all();
        // dd($data);

        return view('pages.korban.edit', compact('pageName','data','bencana','katusia','kondisi','kelurahan'));
    }

    public function update(Request $request, $id, $slug)
    {
        // dd($request);
        $validated = $request->validate([
            'bencana_id'        => 'required',
            'nik'               => 'required',
            'kk'                => 'required',
            'nama'              => 'required',
            'panggilan'         => 'required',
            'jk'                => 'required',
            'usia'              => 'required',
            'kategoriusia_id'   => 'required',
            'kondisi_id'        => 'required',
            'disabilitas'       => 'required',
            'keterangan'        => 'required',
            'kelurahan_id'      => 'required',
            'rw'                => 'required',
            'rt'                => 'required',
            'alamat'            => 'required',
        ], [
            'bencana_id.required'       => 'Harap mengisi data',
            'nik.required'              => 'Harap mengisi data',
            'kk.required'               => 'Harap mengisi data',
            'nama.required'             => 'Harap mengisi data',
            'panggilan.required'        => 'Harap mengisi data',
            'jk.required'               => 'Harap mengisi data',
            'usia.required'             => 'Harap mengisi data',
            'kategoriusia_id.required'  => 'Harap mengisi data',
            'kondisi_id.required'       => 'Harap mengisi data',
            'disabilitas.required'      => 'Harap mengisi data',
            'keterangan.required'       => 'Harap mengisi data',
            'kelurahan_id.required'     => 'Harap mengisi data',
            'rw.required'               => 'Harap mengisi data',
            'rt.required'               => 'Harap mengisi data',
            'alamat.required'           => 'Harap mengisi data',
        ]);

        $bencana = Bencana::where('slug', $slug)->first();

        $data = $request->all();

        $korban = Korban::findOrFail($id);
        $data['user_id'] = Auth::user()->id;

        $update = $korban->update($data);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('korban.bencana', $bencana->slug);
    }

    public function destroy($id, $slug)
    {
        $bencana = Bencana::where('slug', $slug)->first();

        $data = Korban::findOrFail($id);
        $delete = $data->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('korban.bencana', $bencana->slug);
    }

    public function korban($slug)
    {
        $bencana       = Bencana::where('slug', $slug)->first();
        $pageName   = "Korban".$bencana->judul;
        $korban     = Korban::join('bencana', 'bencana.id', '=', 'korban.bencana_id')
                    ->join('kondisi_korban', 'korban.kondisi_id', '=', 'kondisi_korban.id' )
                    ->join('kategori_usia', 'kategori_usia.id', '=', 'korban.kategoriusia_id')
                    ->where('bencana.slug', $slug)->orderBy('korban.id')->get(['korban.id', 'korban.*']);
        // dd($korban);

        return view('pages.korban.korban', compact('pageName', 'korban', 'bencana'));
    }
}
