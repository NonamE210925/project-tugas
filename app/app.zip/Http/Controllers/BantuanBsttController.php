<?php

namespace App\Http\Controllers;

use App\Models\BantuanBstt;
use App\Models\Bencana;
use App\Models\Korban;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use File;

class BantuanBsttController extends Controller
{
    public function index()
    {
        $pageName   = "Bantuan Sosial Tidak Terencana BPBD - PERUMKIM";
        $data       = BantuanBstt::all();
        $korban     = Korban::all();
        $bencana    = Bencana::all();

        return view('pages.bantuan-bstt.index', compact('pageName', 'data', 'korban', 'bencana'));
    }

    public function add()
    {
        $pageName   = "Form Tambah Bantuan Sosial Tidak Terencana BPBD - PERUMKIM";
        $data       = Korban::all();
        $bencana    = Bencana::all();
        $korban     = Korban::all();

        return view('pages.bantuan-bstt.tambah', compact('pageName', 'data', 'bencana', 'korban'));
    }

    public function store(Request $request)
    {
        // dd($request);
        $validated = $request->validate([
            'bencana_id'        => 'required',
            'korban_id'        => 'required',
            'nik'               => 'required',
            'kk'                => 'required',
            'jumlah'              => 'required',
            'keterangan'         => 'required',
            'dampak'                => 'required',
            'foto'              => 'required',
            'sp_kelurahan'  => 'required',
            'sp_bpbd'        => 'required',
            'sp_pencairan'       => 'required',
            'tgl_pencairan'        => 'required',
            
        ], [
            'bencana_id.required'       => 'Harap mengisi data',
            'korban_id.required'                 => 'Harap mengisi data',
            'nik.required'              => 'Harap mengisi data',
            'kk.required'               => 'Harap mengisi data',
            'jumlah.required'             => 'Harap mengisi data',
            'keterangan.required'        => 'Harap mengisi data',
            'dampak.required'               => 'Harap mengisi data',
            'foto.required'             => 'Harap mengisi data',
            'sp_kelurahan.required' => 'Harap mengisi data',
            'sp_bpbd.required'       => 'Harap mengisi data',
            'sp_pencairan.required'      => 'Harap mengisi data',
            'tgl_pencairan.required'       => 'Harap mengisi data',
        ]);


        // dd($data);
        $data = $request->all();

         // upload image
         if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $ext = $file->getClientOriginalExtension();
            $newName =  date('dmY') . $file->getClientOriginalName() . '.' . $ext;
            $file->move('uploads/foto-kerusakan', $newName);
            $data['foto'] = $newName;
        }

        $data['user_id'] = Auth::user()->id;
        BantuanBstt::create($data);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('bantuanBstt');
    }

    public function edit($id)
    {
        $pageName   = "Form Edit Data";
        $data       = BantuanBstt::findOrFail($id);
        $bencana    = Bencana::all();
        $korban     = Korban::all();

        return view('pages.bantuan-bstt.edit', compact('pageName','data','bencana','korban'));
    }

    public function update(Request $request, $id)
    {
            //   dd($request->all());
              $validated = $request->validate([
                'bencana_id'        => 'required',
                'korban_id'        => 'required',
                'nik'               => 'required',
                'kk'                => 'required',
                'jumlah'              => 'required',
                'keterangan'         => 'required',
                'dampak'                => 'required',
                'sp_kelurahan'  => 'required',
                'sp_bpbd'        => 'required',
                'sp_pencairan'       => 'required',
                'tgl_pencairan'        => 'required',
                
            ], [
                'bencana_id.required'       => 'Harap mengisi data',
                'korban_id.required'                 => 'Harap mengisi data',
                'nik.required'              => 'Harap mengisi data',
                'kk.required'               => 'Harap mengisi data',
                'jumlah.required'             => 'Harap mengisi data',
                'keterangan.required'        => 'Harap mengisi data',
                'dampak.required'               => 'Harap mengisi data',
                'sp_kelurahan.required' => 'Harap mengisi data',
                'sp_bpbd.required'       => 'Harap mengisi data',
                'sp_pencairan.required'      => 'Harap mengisi data',
                'tgl_pencairan.required'       => 'Harap mengisi data',
            ]);

        $data = $request->all();

        $bantuan = BantuanBstt::findOrFail($id);

        // update image if exists
        if ($request->hasFile('foto')) {
            // delete old image
            if ($bantuan->foto) {
                File::delete('uploads/foto-kerusakan/' . $bantuan->foto);
                // unlink(public_path('uploads/uttp/' . $item->gambar));
            }
            $file = $request->file('foto');
            $ext = $file->getClientOriginalExtension();
            $newName = date('dmY') . $file->getClientOriginalName() . '.' . $ext;
            $file->move('uploads/foto-kerusakan', $newName);
            $data['foto'] = $newName;
        }else{
            $data['foto'] = $bantuan->foto;
        }

        $data['user_id'] = Auth::user()->id;

        $update = $bantuan->update($data);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('bantuanBstt');
    }

    public function destroy($id)
    {
        $data = BantuanBstt::findOrFail($id);
        $delete = $data->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('bantuanBstt');

    }
}
