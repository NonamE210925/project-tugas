<?php

namespace App\Http\Controllers;

use App\Models\Kerusakan;
use App\Models\Bencana;
use App\Models\Bangunan;
use App\Models\Sektor;
use Illuminate\Http\Request;
use Auth;

class KerusakanController extends Controller
{
    public function index()
    {
        $pageName = "Kerusakan";
        $kerusakan = Kerusakan::with('bencana', 'bangunan', 'sektor')->orderBy('bencana_id')->get();
        return view('pages.kerusakan.index', compact('pageName', 'kerusakan'));
    }

    public function kerusakan($slug)
    {
        $bencana = Bencana::where('slug', $slug)->first();

        $pageName = "Data Kerusakan ".$bencana->judul;
        $kerusakan = Kerusakan::join('bencana', 'bencana.id', '=', 'kerusakan.bencana_id', 'inner')->with('bencana', 'bangunan', 'sektor')
                    ->where('bencana.slug', $slug)->orderBy('kerusakan.id')->get(['kerusakan.id', 'kerusakan.*']);
        return view('pages.kerusakan.kerusakan', compact('pageName', 'bencana', 'kerusakan'));
    }

    public function add($slug)
    {
        $pageName = "Form Tambah Data Kerusakan";
        $bencana = Bencana::where('slug', $slug)->first();
        $bangunan = Bangunan::orderBy('bangunan', 'asc')->get();
        $sektor = Sektor::orderBy('sektor', 'asc')->get();

        return view('pages.kerusakan.tambah', compact('pageName', 'bencana', 'bangunan', 'sektor'));
    }

    public function store(Request $request, $slug)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'jeniskerusakan' => 'required',
            'kerusakan' => 'required',
            'kerugian' => 'required',
        ], [
            'bencana_id.required' => 'Data bencana belum dipilih',
            'jeniskerusakan.required' => 'Harap mengisi data jenis kerusakan',
            'bangunan_id.required' => 'Data bangunan belum dipilih',
            'sektor_id.required' => 'Data sektor belum dipilih',
            'kerusakan.required' => 'Harap mengisi data tingkat kerusakan',
            'kerugian.required' => 'Harap mengisi data kerugian',
        ]);

        $ben = Bencana::where('slug', $slug)->first();

        $data = $request->all();
        $data['user_id'] = Auth::user()->id;

        if($request->jeniskerusakan == "Bangunan") {
            $data['sektor_id'] = 0;
        }
        else{
            $data['bangunan_id'] = 0;
        }

        $store = Kerusakan::create($data);

        session()->flash('success', 'Data Kerusakan Berhasil Ditambahkan.');
        return redirect()->route('kerusakan.bencana', $ben->slug);
    }

    public function edit($id, $slug)
    {
        $pageName = "Form Edit Data Kerusakan";
        $kerusakan = Kerusakan::findOrFail($id);
        $bencana = Bencana::where('slug', $slug)->first();
        $bangunan = Bangunan::orderBy('bangunan', 'asc')->get();
        $sektor = Sektor::orderBy('sektor', 'asc')->get();
        return view('pages.kerusakan.edit', compact('pageName', 'kerusakan', 'bencana', 'bangunan', 'sektor'));
    }

    public function update(Request $request, $id, $slug)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'jeniskerusakan' => 'required',
            'kerusakan' => 'required',
            'kerugian' => 'required',
        ], [
            'bencana_id.required' => 'Data bencana belum dipilih',
            'jeniskerusakan.required' => 'Harap mengisi data jenis kerusakan',
            'bangunan_id.required' => 'Data bangunan belum dipilih',
            'sektor_id.required' => 'Data sektor belum dipilih',
            'kerusakan.required' => 'Harap mengisi data tingkat kerusakan',
            'kerugian.required' => 'Harap mengisi data kerugian',
        ]);

        $ben = Bencana::where('slug', $slug)->first();

        $data = $request->all();
        $data['user_id'] = Auth::user()->id;

        if($request->jeniskerusakan == "Bangunan") {
            $data['sektor_id'] = 0;
        }
        else{
            $data['bangunan_id'] = 0;
        }
        $kerusakan = Kerusakan::findOrFail($id);

        $update = $kerusakan->update($data);

        session()->flash('success', 'Data Kerusakan Berhasil Diupdate.');
        return redirect()->route('kerusakan.bencana', $ben->slug);
    }

    public function destroy($id, $slug)
    {
        $ben = Bencana::where('slug', $slug)->first();
        
        $kerusakan = Kerusakan::findOrFail($id);
        $delete = $kerusakan->delete();

        session()->flash('success', 'Data Kerusakan Berhasil Dihapus.');
        return redirect()->route('kerusakan.bencana', $ben->slug);

    }

}
