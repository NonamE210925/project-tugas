<?php

namespace App\Http\Controllers;

use App\Models\Bencana;
use App\Models\Berita;
use App\Models\JenisBencana;
use App\Models\Kelurahan;
use Illuminate\Http\Request;
use File;
use Carbon\Carbon;

class BencanaController extends Controller
{
    public function index()
    {
        Carbon::setLocale('id');
        $pageName = "Kejadian Bencana";
        $Bencana = Bencana::with('jenis', 'kelurahan')->orderBy('judul')->get();
        return view('pages.bencana.index', compact('pageName', 'Bencana'));
    }

    public function add()
    {
        $pageName = "Form Tambah Kejadian Bencana";
        $jenisBencana = JenisBencana::all();
        $kelurahan = Kelurahan::all();
        return view('pages.bencana.tambah', compact('pageName', 'jenisBencana', 'kelurahan'));
    }

    public function store(Request $request)
    {
        $qey = Bencana::orderBy('id', 'DESC')->limit(1)->first();
        $validated = $request->validate([
            'judul' => 'required',
            'jenis_id' => 'required',
            'tgl' => 'required',
            'waktu' => 'required',
            'kelurahan_id' => 'required',
            'alamat' => 'required',
            'cakupan' => 'required',
            'lat' => 'required',
            'lng' => 'required',
            'peta' => 'mimes:geojson',
            'penyebab' => 'required',
            'deskripsi' => 'required',
            'foto' => 'required',
        ], [
            'jenis.required' => 'Harap mengisi data',
            'jenis_id.required' => 'Harap mengisi data',
            'tgl.required' => 'Harap mengisi data',
            'waktu.required' => 'Harap mengisi data',
            'kelurahan_id.required' => 'Harap mengisi data',
            'alamat.required' => 'Harap mengisi data',
            'cakupan.required' => 'Harap mengisi data',
            'lat.required' => 'Harap mengisi data',
            'lng.required' => 'Harap mengisi data',
            // 'peta.required' => 'Harap mengisi data',
            'penyebab.required' => 'Harap mengisi data',
            'deskripsi.required' => 'Harap mengisi data',
            'foto.required' => 'Harap mengisi data',
        ]);

        $attr = $request->all();

        // upload image
        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $ext = $file->getClientOriginalExtension();
            $newName =  date('dmY') . $file->getClientOriginalName() . '.' . $ext;
            $file->move('uploads/kejadian-bencana', $newName);
            $attr['foto'] = $newName;
        }

        if ($request->hasFile('peta')) {
            $file = $request->file('peta');
            $ext = $file->getClientOriginalExtension();
            $newName =  $qey->id + 1 . '.' . $ext;
            $file->move('uploads/peta', $newName);
            $attr['peta'] = $newName;
        }

        $attr['slug'] = \Str::slug($request->judul . ' ' . $qey->id);
        $attr['user_id'] = auth()->user()->id;

        $store = Bencana::create($attr);

        // input berita
        $berita['bencana_id'] = $store->id;
        $berita['judul'] = $store->judul;
        $berita['slug'] = $store->slug;
        $berita['kategori_id'] =  $store->jenis_id;
        $berita['tgl'] = now();
        $berita['isi'] = "-";
        $berita['foto'] = $store->foto;
        $berita['user_id'] = auth()->user()->id;

        $storeBerita = Berita::create($berita);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('bencana');
    }

    public function edit(Request $request, $id)
    {
        $pageName = "Form Edit Kejadian Bencana";
        $Bencana = Bencana::findOrFail($id);
        $jenisBencana = JenisBencana::all();
        $kelurahan = Kelurahan::all();
        return view('pages.bencana.edit', compact('pageName', 'Bencana', 'jenisBencana', 'kelurahan'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'judul' => 'required',
            'jenis_id' => 'required',
            'tgl' => 'required',
            'waktu' => 'required',
            'kelurahan_id' => 'required',
            'alamat' => 'required',
            'cakupan' => 'required',
            'lat' => 'required',
            'lng' => 'required',
            'peta' => 'mimes:geojson',
            'penyebab' => 'required',
            'deskripsi' => 'required',
        ], [
            'jenis.required' => 'Harap mengisi data',
            'jenis_id.required' => 'Harap mengisi data',
            'tgl.required' => 'Harap mengisi data',
            'waktu.required' => 'Harap mengisi data',
            'kelurahan_id.required' => 'Harap mengisi data',
            'alamat.required' => 'Harap mengisi data',
            'cakupan.required' => 'Harap mengisi data',
            'lat.required' => 'Harap mengisi data',
            'lng.required' => 'Harap mengisi data',
            'penyebab.required' => 'Harap mengisi data',
            'deskripsi.required' => 'Harap mengisi data',
        ]);

        $attr = $request->all();

        $bencana = Bencana::findOrFail($id);

        // update image if exists
        if ($request->hasFile('foto')) {
            // delete old image
            if ($bencana->foto) {
                File::delete('uploads/kejadian-bencana/' . $bencana->foto);
                // unlink(public_path('uploads/uttp/' . $item->gambar));
            }
            $file = $request->file('foto');
            $ext = $file->getClientOriginalExtension();
            $newName = date('dmY') . $file->getClientOriginalName() . '.' . $ext;
            $file->move('uploads/kejadian-bencana', $newName);
            $attr['foto'] = $newName;
        } else {
            $data['foto'] = $bencana->foto;
        }

        if ($request->hasFile('peta')) {
            // delete old image
            if ($bencana->peta) {
                File::delete('uploads/peta/' . $bencana->peta);
                // unlink(public_path('uploads/uttp/' . $item->gambar));
            }
            $file = $request->file('peta');
            $ext = $file->getClientOriginalExtension();
            $newName = $bencana->peta;
            $file->move('uploads/peta', $newName);
            $attr['peta'] = $newName;
        } else {
            $data['peta'] = $bencana->peta;
        }


        $update = $bencana->update($attr);

        // // update berita
        // $berita['bencana_id'] = $bencana->id;
        // $berita['judul'] = $request->judul;
        // $berita['slug'] = $bencana->slug;
        // $berita['kategori_id'] =  $request->jenis_id;
        // $berita['tgl'] = now();
        // $berita['isi'] = "-";
        // $berita['foto'] =  $data['foto'];
        // $berita['user_id'] = auth()->user()->id;

        // $beritas = Berita::where('bencana_id', '=', $bencana->id)->first();
        // // dd($berita);
        // $updateBerita = $beritas->update($berita);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('bencana');
    }

    public function destroy($id)
    {
        $Bencana = Bencana::findOrFail($id);
        $delete = $Bencana->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('bencana');
    }
}
