<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BantuanNatura;
use App\Models\Bencana;
use App\Models\Korban;

class BantuanNaturaController extends Controller
{
    public function index()
    {
        $pageName = "Bantuan Natura";
        $natura = BantuanNatura::all();
        return view('pages.bantuan-natura.index', compact('pageName', 'natura'));
    }

    public function add()
    {
        $pageName = "Form Tambah Bantuan Natura";
        $bencana = Bencana::all();
        $korban = Korban::all();
        return view('pages.bantuan-natura.tambah', compact('pageName', 'bencana', 'korban'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'korban_id' => 'required',
            'nik' => 'required',
            'kk' => 'required',
            'jumlah' => 'required',
            'keterangan' => 'required',
            'surat_usulan' => 'required',
            'berita_acara' => 'required',
            'status' => 'required',
        ], [
            'jenis.required' => 'Harap mengisi data',
            'bencana_id.required' => 'Harap mengisi data',
            'korban_id.required' => 'Harap mengisi data',
            'nik.required' => 'Harap mengisi data',
            'kk.required' => 'Harap mengisi data',
            'jumlah.required' => 'Harap mengisi data',
            'keterangan.required' => 'Harap mengisi data',
            'surat_usulan.required' => 'Harap mengisi data',
            'berita_acara.required' => 'Harap mengisi data',
            'status.required' => 'Harap mengisi data'
        ]);

        $attr = $request->all();
        $store = BantuanNatura::create($attr);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('bantuanNatura');
    }

    public function edit($id)
    {
        $pageName = "Form Edit Tambah Bantuan Natura";
        $bencana = Bencana::all();
        $korban = Korban::all();
        $bantuanNatura = BantuanNatura::findOrFail($id);

        return view('pages.bantuan-natura.edit', compact('pageName', 'bencana', 'korban', 'bantuanNatura'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'korban_id' => 'required',
            'nik' => 'required',
            'kk' => 'required',
            'jumlah' => 'required',
            'keterangan' => 'required',
            'surat_usulan' => 'required',
            'berita_acara' => 'required',
            'status' => 'required',
        ], [
            'jenis.required' => 'Harap mengisi data',
            'bencana_id.required' => 'Harap mengisi data',
            'korban_id.required' => 'Harap mengisi data',
            'nik.required' => 'Harap mengisi data',
            'kk.required' => 'Harap mengisi data',
            'jumlah.required' => 'Harap mengisi data',
            'keterangan.required' => 'Harap mengisi data',
            'surat_usulan.required' => 'Harap mengisi data',
            'berita_acara.required' => 'Harap mengisi data',
            'status.required' => 'Harap mengisi data'
        ]);

        $attr = $request->all();
        $bantuanNatura = BantuanNatura::findOrFail($id);

        $update = $bantuanNatura->update($attr);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('bantuanNatura');
    }

    public function destroy($id)
    {
        $bantuanNatura = BantuanNatura::findOrFail($id);
        $delete = $bantuanNatura->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('bantuanNatura');
    }
}
