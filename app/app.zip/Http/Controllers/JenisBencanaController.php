<?php

namespace App\Http\Controllers;

use App\Models\JenisBencana;
use Illuminate\Http\Request;

class JenisBencanaController extends Controller
{
    public function index()
    {
        $pageName = "Jenis Bencana";
        $jenisBencana = JenisBencana::orderBy('jenis')->get();
        return view('pages.jenis-bencana.index', compact('pageName', 'jenisBencana'));
    }

    public function add()
    {
        $pageName = "Form Tambah Bencana";
        return view('pages.jenis-bencana.tambah', compact('pageName'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'jenis' => 'required',
        ], [
            'jenis.required' => 'Harap mengisi data'
        ]);

        $data = $request->all();
        $store = JenisBencana::create($data);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('jenisbencana');
    }

    public function edit($id)
    {
        $pageName = "Form Edit Data";
        $jenisBencana = JenisBencana::findOrFail($id);
        return view('pages.jenis-bencana.edit', compact('pageName', 'jenisBencana'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'jenis' => 'required',
        ], [
            'jenis.required' => 'Harap mengisi data'
        ]);

        $data = $request->all();

        $jenisBencana = JenisBencana::findOrFail($id);
        $update = $jenisBencana->update($data);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('jenisbencana');
    }

    public function destroy($id)
    {
        $jenisBencana = JenisBencana::findOrFail($id);
        $delete = $jenisBencana->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('jenisbencana');

    }
}
