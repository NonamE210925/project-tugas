<?php

namespace App\Http\Controllers;

use App\Models\Bencana;
use App\Models\Berita;
use Carbon\Carbon;
use Illuminate\Http\Request;

class BeritaController extends Controller
{
    public function index()
    {
        Carbon::setLocale('id');
        $pageName = "Berita Bencana";
        $berita = Berita::all();
        return view('pages.berita.index', compact('pageName', 'berita'));
    }

    public function add()
    {
        $pageName = "Form Tambah Berita Bencana";
        $bencana = Bencana::all();
        return view('pages.berita.tambah', compact('pageName', 'bencana'));
    }
}
