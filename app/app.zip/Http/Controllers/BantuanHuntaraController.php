<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BantuanHuntara;
use App\Models\Bencana;
use App\Models\Korban;
use App\Models\Bank;
use Auth;

class BantuanHuntaraController extends Controller
{
    public function index()
    {
        $pageName = "Bantuan Huntara";
        $huntara = BantuanHuntara::with('bencana', 'korban')->orderBy('bencana_id')->get();
        return view('pages.bantuan-huntara.index', compact('pageName', 'huntara'));
    }

    public function add()
    {
        $pageName = "Form Tambah Huntara";
        $bencana = Bencana::all();
        $korban = Korban::orderBy('nama', 'asc')->get();
        $bank = Bank::orderBy('bank', 'asc')->get();

        return view('pages.bantuan-huntara.tambah', compact('pageName', 'bencana', 'korban', 'bank'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'korban_id' => 'required',
            'nik' => 'required',
            'kk' => 'required',
            'jumlah_jiwa' => 'required',
            'keterangan' => 'required',
            'volume' => 'required',
            'bank_id' => 'required',
            'rekening' => 'required',
            'nama_pemilik' => 'required',
            'tgl_usulan' => 'required',
            'tgl_pencairan' => 'required',
            'jumlah' => 'required',
            'pph' => 'required',
            'jml_bayar' => 'required',
            'status' => 'required',
        ], [
            'bencana_id.required' => 'Data bencana belum dipilih',
            'korban_id.required' => 'Data korban belum dipilih',
            'nik.required' => 'Harap mengisi data NIK',
            'kk.required' => 'Harap mengisi data KK',
            'jumlah_jiwa.required' => 'Harap mengisi data jumlah jiwa',
            'keterangan.required' => 'Harap mengisi data keterangan',
            'volume.required' => 'Harap mengisi data volume',
            'bank_id.required' => 'Nama bank belum dipilih',
            'rekening.required' => 'Harap mengisi data rekening',
            'nama_pemilik.required' => 'Harap mengisi nama pemilik rekening',
            'tgl_usulan.required' => 'Harap mengisi tanggal usulan',
            'tgl_pencairan.required' => 'Harap mengisi tanggal pencairan',
            'jumlah.required' => 'Harap mengisi jumlah',
            'pph.required' => 'Harap mengisi pph',
            'jml_bayar.required' => 'Harap mengisi jumlah bayar',
            'status.required' => 'Harap mengisi status',
        ]);

        $data = $request->all();
        $data['user_id'] = Auth::user()->id;

        $store = BantuanHuntara::create($data);

        session()->flash('success', 'Data Huntara Berhasil Ditambahkan.');
        return redirect()->route('bantuanHuntara');
    }

    public function edit(Request $request, $id)
    {
        $pageName = "Form Edit Huntara";
        $huntara = BantuanHuntara::findOrFail($id);
        $bencana = Bencana::all();
        $korban = Korban::orderBy('nama', 'asc')->get();
        $bank = Bank::orderBy('bank', 'asc')->get();
        return view('pages.bantuan-huntara.edit', compact('pageName', 'huntara', 'bencana', 'korban', 'bank'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'korban_id' => 'required',
            'nik' => 'required',
            'kk' => 'required',
            'jumlah_jiwa' => 'required',
            'keterangan' => 'required',
            'volume' => 'required',
            'bank_id' => 'required',
            'rekening' => 'required',
            'nama_pemilik' => 'required',
            'tgl_usulan' => 'required',
            'tgl_pencairan' => 'required',
            'jumlah' => 'required',
            'pph' => 'required',
            'jml_bayar' => 'required',
            'status' => 'required',
        ], [
            'bencana_id.required' => 'Data bencana belum dipilih',
            'korban_id.required' => 'Data korban belum dipilih',
            'nik.required' => 'Harap mengisi data NIK',
            'kk.required' => 'Harap mengisi data KK',
            'jumlah_jiwa.required' => 'Harap mengisi data jumlah jiwa',
            'keterangan.required' => 'Harap mengisi data keterangan',
            'volume.required' => 'Harap mengisi data volume',
            'bank_id.required' => 'Nama bank belum dipilih',
            'rekening.required' => 'Harap mengisi data rekening',
            'nama_pemilik.required' => 'Harap mengisi nama pemilik rekening',
            'tgl_usulan.required' => 'Harap mengisi tanggal usulan',
            'tgl_pencairan.required' => 'Harap mengisi tanggal pencairan',
            'jumlah.required' => 'Harap mengisi jumlah',
            'pph.required' => 'Harap mengisi pph',
            'jml_bayar.required' => 'Harap mengisi jumlah bayar',
            'status.required' => 'Harap mengisi status',
        ]);

        $data = $request->all();
        $data['user_id'] = Auth::user()->id;

        $huntara = BantuanHuntara::findOrFail($id);

        $update = $huntara->update($data);

        session()->flash('success', 'Data Huntara Berhasil Diupdate.');
        return redirect()->route('bantuanHuntara');
    }

    public function destroy($id)
    {
        $huntara = BantuanHuntara::findOrFail($id);
        $delete = $huntara->delete();

        session()->flash('success', 'Data Huntara Berhasil Dihapus.');
        return redirect()->route('bantuanHuntara');

    }
}
