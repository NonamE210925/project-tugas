<?php

namespace App\Http\Controllers;

use App\Models\FotoBencana;
use App\Models\Bencana;
use Illuminate\Http\Request;
use File;

class FotobencanaController extends Controller
{
    public function index()
    {
        $pageName = "Foto Bencana";
        $fotoBencana = FotoBencana::with('bencana')->orderBy('bencana_id')->get();
        return view('pages.foto-bencana.index', compact('pageName', 'fotoBencana'));
    }

    public function fotobencana($slug)
    {
        $bencana = Bencana::where('slug', $slug)->first();
        
        $pageName = "Foto-Foto Bencana ".$bencana->judul;
        $fotoBencana = FotoBencana::join('bencana', 'bencana.id', '=', 'foto_bencana.bencana_id', 'inner')->with('bencana')
                        ->where('bencana.slug', $slug)->orderBy('foto_bencana.id')->get(['foto_bencana.id', 'foto_bencana.*']);
        return view('pages.foto-bencana.fotobencana', compact('pageName', 'bencana', 'fotoBencana'));
    }

    public function add($slug)
    {
        $pageName = "Form Tambah Foto Bencana";
        $bencana = Bencana::where('slug', $slug)->first();
        return view('pages.foto-bencana.tambah', compact('pageName', 'bencana'));
    }

    public function store(Request $request, $slug)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'foto' => 'required',
        ], [
            'foto.required' => 'Harap upload data foto'
        ]);

        $ben = Bencana::where('slug', $slug)->first();

        $data = $request->all();

        // upload image
        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $ext = $file->getClientOriginalExtension();
            $newName =  date('dmY') . $file->getClientOriginalName() . '.' . $ext;
            $file->move('uploads/foto-bencana', $newName);
            $data['foto'] = $newName;
        }

        $store = FotoBencana::create($data);

        session()->flash('success', 'Foto Bencana Berhasil Ditambahkan.');
        return redirect()->route('fotobencana.bencana', $ben->slug);
    }

    public function edit($id, $slug)
    {
        $pageName = "Form Edit Data Foto";
        $fotoBencana = FotoBencana::findOrFail($id);
        $bencana = Bencana::where('slug', $slug)->first();
        return view('pages.foto-bencana.edit', compact('pageName', 'bencana', 'fotoBencana'));
    }

    public function update(Request $request, $id, $slug)
    {
        $validated = $request->validate([
            'bencana_id' => 'required',
            'foto' => 'required',
        ], [
            'foto.required' => 'Harap upload data foto'
        ]);

        $ben = Bencana::where('slug', $slug)->first();

        $data = $request->all();

        $fotoBencana = FotoBencana::findOrFail($id);

        // update image if exists
        if ($request->hasFile('foto')) {
            // delete old image
            if ($fotoBencana->foto) {
                File::delete('uploads/foto-bencana/' . $fotoBencana->foto);
                // unlink(public_path('uploads/uttp/' . $item->gambar));
            }
            $file = $request->file('foto');
            $ext = $file->getClientOriginalExtension();
            $newName = date('dmY') . $file->getClientOriginalName() . '.' . $ext;
            $file->move('uploads/foto-bencana', $newName);
            $data['foto'] = $newName;
        }else{
            $data['foto'] = $fotoBencana->foto;
        }

        $update = $fotoBencana->update($data);

        session()->flash('success', 'Foto Berhasil Diupdate.');
        return redirect()->route('fotobencana.bencana', $ben->slug);
    }

    public function destroy($id, $slug)
    {
        $ben = Bencana::where('slug', $slug)->first();

        $fotoBencana = FotoBencana::findOrFail($id);
        $delete = $fotoBencana->delete();

        session()->flash('error', 'Foto Berhasil Dihapus.');
        return redirect()->route('fotobencana.bencana', $ben->slug);

    }
}
