<?php

namespace App\Http\Controllers;

use App\Models\Kecamatan;
use Illuminate\Http\Request;

class KecamatanController extends Controller
{
    public function index()
    {
        $pageName = "Kecamatan";
        $kecamatan = Kecamatan::all();
        // dd($kecamatan);
        return view('pages.kecamatan.index', compact('pageName', 'kecamatan'));
    }

    public function add()
    {
        $pageName = "Form Tambah Kecamatan";
        return view('pages.kecamatan.tambah', compact('pageName'));
    }

    public function store(Request $request)
    {
        // dd($request);
        $validated = $request->validate([
            'nama_kecamatan' => 'required',
        ], [
            'nama_kecamatan.required' => 'Harap mengisi data'
        ]);

        $data = $request->all();
        $store = Kecamatan::create($data);

        session()->flash('success', 'Data Berhasil Ditambahkan!.');
        return redirect()->route('kecamatan');
    }

    public function edit($id)
    {
        $pageName = "Form Edit Data";
        $data = Kecamatan::findOrFail($id);
        return view('pages.kecamatan.edit', compact('pageName', 'data'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'nama_kecamatan' => 'required',
        ], [
            'nama_kecamatan.required' => 'Harap mengisi data'
        ]);

        $data = $request->all();

        $kecamatan = Kecamatan::findOrFail($id);
        $update = $kecamatan->update($data);

        session()->flash('success', 'Data Berhasil Diupdate!.');
        return redirect()->route('kecamatan');
    }

    public function destroy($id)
    {
        $kecamatan = Kecamatan::findOrFail($id);
        $delete = $kecamatan->delete();

        session()->flash('error', 'Data Berhasil Dihapus!.');
        return redirect()->route('kecamatan');

    }
}
