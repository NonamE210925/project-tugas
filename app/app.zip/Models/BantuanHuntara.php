<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BantuanHuntara extends Model
{
    use HasFactory;
    protected $table = 'huntara';

    protected $fillable = ['bencana_id', 'korban_id', 'nik', 'kk', 'jumlah_jiwa', 'keterangan', 'volume', 'bank_id', 'rekening', 'nama_pemilik', 'tgl_usulan', 'tgl_pencairan', 'jumlah', 'pph', 'jml_bayar', 'status', 'user_id'];

    public function bencana()
    {
        return $this->belongsTo(Bencana::class, 'bencana_id', 'id');
    }

    public function korban()
    {
        return $this->belongsTo(Korban::class, 'korban_id', 'id');
    }    

    public function bank()
    {
        return $this->belongsTo(Bank::class, 'bank_id', 'id');
    }
}
