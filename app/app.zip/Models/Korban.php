<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Korban extends Model
{
    use HasFactory;

    protected $table = 'korban';

    protected $fillable = [
        'bencana_id', 'nik', 'kk', 'nama', 'panggilan', 'jk', 'usia', 'kategoriusia_id', 'kondisi_id', 'disabilitas',
        'keterangan', 'kelurahan_id', 'rw', 'rt', 'alamat', 'user_id'
    ];

    public function bencana()
    {
        return $this->belongsTo(Bencana::class, 'bencana_id');
    }

    public function kategoriusia()
    {
        return $this->belongsTo(KategoriUsia::class, 'kategoriusia_id');
    }

    public function kondisikorban()
    {
        return $this->belongsTo(KondisiKorban::class, 'kondisi_id');
    }

    public function kelurahan()
    {
        return $this->belongsTo(Kelurahan::class, 'kelurahan_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function bantuannatura()
    {
        return $this->hasMany(BantuanNatura::class, 'korban_id');
    }
}
