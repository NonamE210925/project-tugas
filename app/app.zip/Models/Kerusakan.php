<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kerusakan extends Model
{
    use HasFactory;

    protected $table = 'kerusakan';

    protected $fillable = ['bencana_id', 'jeniskerusakan', 'bangunan_id', 'sektor_id', 'kerusakan', 'kerugian', 'user_id'];

    public function bencana()
    {
        return $this->belongsTo(Bencana::class, 'bencana_id', 'id');
    }

    public function bangunan()
    {
        return $this->belongsTo(Bangunan::class, 'bangunan_id', 'id');
    }

    public function sektor()
    {
        return $this->belongsTo(Sektor::class, 'sektor_id', 'id');
    }

    // public function user()
    // {
    //     return $this->belongsTo(Bangunan::class, 'user_id');
    // }
}
