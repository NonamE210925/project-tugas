<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Berita extends Model
{
    use HasFactory;

    protected $table = 'berita';

    protected $fillable = ['bencana_id', 'judul', 'slug', 'kategori_id', 'tgl', 'isi', 'foto', 'user_id'];

    protected $dates = ['tgl'];

    public function jenis()
    {
        return $this->belongsTo(JenisBencana::class, 'kategori_id', 'id');
    }
}
