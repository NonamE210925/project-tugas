<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sektor extends Model
{
    use HasFactory;

    protected $table = 'sektor';

    protected $fillable = ['sektor', 'bidang'];

    public function kerusakan()
    {
        return $this->hasMany(Kerusakan::class, 'kerusakan_id');
    }
}
