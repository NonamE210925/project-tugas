<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BantuanNatura extends Model
{
    use HasFactory;
    protected $table = 'natura';

    protected $fillable = ['bencana_id', 'korban_id', 'nik', 'kk', 'jumlah', 'keterangan', 'surat_usulan', 'berita_acara', 'status', 'user_id'];

    public function bencana()
    {
        return $this->belongsTo(Bencana::class, 'bencana_id', 'id');
    }

    public function korban()
    {
        return $this->belongsTo(Korban::class, 'korban_id', 'id');
    }
}
