<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BantuanBstt extends Model
{
    use HasFactory;

    protected $table = 'bstt';

    protected $fillable = [
        'bencana_id','korban_id', 'nik', 'kk', 'jumlah', 'keterangan','dampak','foto',
        'sp_kelurahan','sp_bpbd', 'sp_pencairan','tgl_pencairan', 'user_id'
    ];

    public function bencana()
    {
        return $this->belongsTo(Bencana::class, 'bencana_id');
    }

    public function korban()
    {
        return $this->belongsTo(Korban::class, 'korban_id');
    }
}
