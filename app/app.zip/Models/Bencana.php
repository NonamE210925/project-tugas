<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bencana extends Model
{
    use HasFactory;

    protected $table = 'bencana';

    protected $fillable = ['judul', 'slug', 'jenis_id', 'tgl', 'waktu', 'kelurahan_id', 'alamat', 'cakupan', 'lat', 'lng', 'peta', 'penyebab', 'deskripsi', 'foto', 'user_id'];

    protected $dates = ['tgl'];

    public function jenis()
    {
        return $this->belongsTo(JenisBencana::class, 'jenis_id', 'id');
    }

    public function kelurahan()
    {
        return $this->belongsTo(Kelurahan::class, 'kelurahan_id', 'id');
    }

    public function bencana()
    {
        return $this->hasMany(Bencana::class);
    }

    public function bantuannatura()
    {
        return $this->hasMany(BantuanNatura::class, 'bencana_id');
    }
}
