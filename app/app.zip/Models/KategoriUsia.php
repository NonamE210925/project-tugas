<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KategoriUsia extends Model
{
    use HasFactory;

    protected $table = 'kategori_usia';

    protected $fillable = ['kategori_usia'];

    public function korban()
    {
        return $this->belongsTo(Korban::class);
    }
}
