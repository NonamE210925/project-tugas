<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FotoBencana extends Model
{
    use HasFactory;

    protected $table = 'foto_bencana';

    protected $fillable = ['bencana_id', 'foto'];

    public function bencana()
    {
        return $this->belongsTo(Bencana::class, 'bencana_id');
    }
}
