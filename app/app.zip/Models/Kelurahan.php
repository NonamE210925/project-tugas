<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kelurahan extends Model
{
    use HasFactory;

    protected $table = 'kelurahan';

    protected $fillable = [
        'nama_kelurahan', 'kecamatan_id'
    ];

    public function kec()
    {
        return $this->belongsTo(Kecamatan::class, 'kecamatan_id');
    }

    public function korban()
    {
        return $this->belongsTo(Korban::class,);
    }

    public function biodata()
    {
        return $this->hasMany(biodata::class);
    }

    public function bencana()
    {
        return $this->hasMany(Bencana::class);
    }
    
}
